# NEXUS CALC — Android

Aplicativo Android nativo, offline, com interface dark tecnológica.

## Requisitos
- Android Studio (recomendado: versão recente)
- JDK 17
- Android SDK Platform 35
- Gradle será baixado pelo Android Studio na primeira sincronização.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `NexusCalc` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK 35.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos
- Operações básicas e expressões com parênteses
- Porcentagem: `50% de 100`
- Desconto: `100 com desconto de 30%`
- Acréscimo: `200 com acrescimo de 10%`
- Comparação: `50 é quantos por cento de 200`
- Raiz: `raiz quadrada de 144` ou `sqrt(144)`
- Regra de três: `regra de três 2 10 6`
- Explicações passo a passo e histórico local em memória

O projeto não precisa de permissões especiais nem de conexão à internet durante o uso.

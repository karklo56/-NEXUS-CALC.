package com.nexuscalc.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.InputType
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 21, 28)
    private val panel = Color.rgb(27, 35, 45)
    private val panel2 = Color.rgb(36, 47, 59)
    private val mint = Color.rgb(101, 230, 193)
    private val white = Color.rgb(240, 245, 248)
    private val muted = Color.rgb(145, 160, 174)
    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var explanation: TextView
    private lateinit var historyBox: LinearLayout
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
    }

    private fun rounded(color: Int, radius: Float = 18f): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "∑"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(mint)
            background = rounded(panel2, 15f)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(52), dp(52)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(text("NEXUS CALC", 20f, white, true))
            addView(text("SMART MATHEMATICS", 10f, muted, true))
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val status = text("● READY", 11f, mint, true)
        header.addView(status)
        content.addView(header)
        addSpace(content, 22)

        content.addView(text("EXPRESSÃO MATEMÁTICA", 11f, muted, true))
        addSpace(content, 8)

        input = EditText(this).apply {
            hint = "Ex.: 50% de 100"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 20f
            singleLine = false
            minLines = 2
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 16f)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, dp(86)))
        addSpace(content, 12)

        val calculate = button("CALCULAR  →", mint, Color.rgb(13, 25, 25), true)
        calculate.setOnClickListener { calculateNow() }
        content.addView(calculate, LinearLayout.LayoutParams(-1, dp(52)))
        addSpace(content, 18)

        val resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 18f)
        }
        resultCard.addView(text("RESULTADO", 11f, muted, true))
        result = text("—", 34f, mint, true)
        resultCard.addView(result)
        content.addView(resultCard, LinearLayout.LayoutParams(-1, -2))
        addSpace(content, 16)

        val explainCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 18f)
        }
        explainCard.addView(text("ENTENDA O CÁLCULO", 11f, mint, true))
        addSpace(explainCard, 10)
        explanation = text("Digite uma operação acima. O NEXUS CALC mostrará o resultado e explicará como chegou até ele.", 14f, white)
        explanation.setLineSpacing(dp(5).toFloat(), 1f)
        explainCard.addView(explanation)
        content.addView(explainCard, LinearLayout.LayoutParams(-1, -2))
        addSpace(content, 18)

        content.addView(text("TECLADO RÁPIDO", 11f, muted, true))
        addSpace(content, 9)
        val keys = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "−"),
            listOf("0", ".", "%", "+"),
            listOf("(", ")", "⌫", "C")
        )
        keys.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val b = button(key, if (key in listOf("÷","×","−","+","%")) panel2 else panel, if (key == "C") Color.rgb(255,150,140) else white)
                b.textSize = 18f
                b.setOnClickListener {
                    when (key) {
                        "C" -> input.setText("")
                        "⌫" -> {
                            val s = input.text.toString()
                            if (s.isNotEmpty()) input.setText(s.dropLast(1))
                            input.setSelection(input.text.length)
                        }
                        else -> {
                            val pos = input.selectionStart.coerceAtLeast(0)
                            input.text.insert(pos, key)
                        }
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                line.addView(b, lp)
            }
            content.addView(line)
        }
        addSpace(content, 18)

        val histHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        histHeader.addView(text("HISTÓRICO", 11f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        val clearHist = text("LIMPAR", 10f, mint, true)
        clearHist.setOnClickListener { history.clear(); historyBox.removeAllViews() }
        histHeader.addView(clearHist)
        content.addView(histHeader)
        historyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(historyBox)
        addSpace(content, 16)
        val footer = text("NEXUS CALC  •  V1.0  •  OFFLINE", 10f, muted)
        footer.gravity = Gravity.CENTER
        content.addView(footer)

        setContentView(root)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun button(label: String, color: Int, fg: Int, bold: Boolean = true): TextView {
        return TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(fg)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(color, 14f)
        }
    }

    private fun calculateNow() {
        val raw = input.text.toString().trim()
        if (raw.isEmpty()) {
            explanation.text = "Digite uma operação para começar."
            return
        }
        try {
            val (value, steps) = Interpreter.solve(raw)
            result.text = fmt(value)
            explanation.text = steps.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n\n")
            val entry = "$raw = ${fmt(value)}"
            history.add(0, entry)
            val item = text(entry, 13f, white)
            item.setPadding(dp(10), dp(10), dp(10), dp(10))
            item.background = rounded(panel, 12f)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(5), 0, dp(5))
            historyBox.addView(item, 0, lp)
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(input.windowToken, 0)
        } catch (e: Exception) {
            result.text = "Erro"
            explanation.text = e.message ?: "Não consegui interpretar essa operação. Confira os números e tente novamente."
        }
    }

    private fun fmt(v: Double): String {
        if (!v.isFinite()) return "Indefinido"
        val symbols = DecimalFormatSymbols(Locale.US)
        val df = DecimalFormat("#,##0.##########", symbols)
        return df.format(v).replace(",", "X").replace(".", ",").replace("X", ".")
    }
}

private object Interpreter {
    fun solve(original: String): Pair<Double, List<String>> {
        var s = original.lowercase(Locale.ROOT).trim()
            .replace("×", "*").replace("÷", "/").replace(",", ".")
            .replace("quanto é", "").replace("quanto e", "")
            .replace("calcule", "").replace("calcular", "").trim()

        fun number(x: String) = x.replace(",", ".").toDouble()

        var m = Regex("""(-?\d+(?:\.\d+)?)\s*(?:%|por cento)\s*(?:de|do|da)\s*(-?\d+(?:\.\d+)?)""").find(s)
        if (m != null) {
            val p = number(m.groupValues[1]); val total = number(m.groupValues[2])
            val factor = p / 100.0
            val answer = factor * total
            return answer to listOf(
                "$p% significa $p dividido por 100.",
                "$p ÷ 100 = ${fmtStatic(factor)}.",
                "Multiplicamos o total por esse valor: $total × ${fmtStatic(factor)} = ${fmtStatic(answer)}.",
                "Portanto, $p% de $total é ${fmtStatic(answer)}."
            )
        }

        m = Regex("""(-?\d+(?:\.\d+)?)\s+com\s+desconto\s+de\s+(\d+(?:\.\d+)?)\s*%""").find(s)
        if (m != null) {
            val total = number(m.groupValues[1]); val p = number(m.groupValues[2])
            val discount = total * p / 100.0; val answer = total - discount
            return answer to listOf(
                "O valor inicial é $total.",
                "Calculamos o desconto: $total × $p ÷ 100 = ${fmtStatic(discount)}.",
                "Subtraímos o desconto do valor inicial: $total − ${fmtStatic(discount)} = ${fmtStatic(answer)}.",
                "O valor final é ${fmtStatic(answer)}."
            )
        }

        m = Regex("""(-?\d+(?:\.\d+)?)\s+com\s+(?:acréscimo|acrescimo|aumento)\s+de\s+(\d+(?:\.\d+)?)\s*%""").find(s)
        if (m != null) {
            val total = number(m.groupValues[1]); val p = number(m.groupValues[2])
            val increase = total * p / 100.0; val answer = total + increase
            return answer to listOf(
                "O valor inicial é $total.",
                "Calculamos o acréscimo: $total × $p ÷ 100 = ${fmtStatic(increase)}.",
                "Somamos ao valor inicial: $total + ${fmtStatic(increase)} = ${fmtStatic(answer)}.",
                "O valor final é ${fmtStatic(answer)}."
            )
        }

        m = Regex("""(-?\d+(?:\.\d+)?)\s+(?:é|e)\s+quantos?\s+por\s+cento\s+(?:de|do|da)\s+(-?\d+(?:\.\d+)?)""").find(s)
        if (m != null) {
            val part = number(m.groupValues[1]); val total = number(m.groupValues[2])
            if (total == 0.0) throw IllegalArgumentException("Não é possível dividir por zero.")
            val ratio = part / total; val answer = ratio * 100
            return answer to listOf(
                "Queremos descobrir que porcentagem $part representa de $total.",
                "Dividimos a parte pelo total: $part ÷ $total = ${fmtStatic(ratio)}.",
                "Multiplicamos por 100 para converter em porcentagem: ${fmtStatic(ratio)} × 100 = ${fmtStatic(answer)}%.",
                "Portanto, $part representa ${fmtStatic(answer)}% de $total."
            )
        }

        m = Regex("""(?:qual é )?a?\s*raiz quadrada de\s*(-?\d+(?:\.\d+)?)""").find(s)
        if (m != null) {
            val n = number(m.groupValues[1])
            if (n < 0) throw IllegalArgumentException("Não há raiz quadrada real de um número negativo.")
            val answer = sqrt(n)
            return answer to listOf(
                "A raiz quadrada procura um número que, multiplicado por ele mesmo, resulta em $n.",
                "Calculamos √$n.",
                "Como ${fmtStatic(answer)} × ${fmtStatic(answer)} = ${fmtStatic(answer * answer)}, o resultado é ${fmtStatic(answer)}."
            )
        }

        m = Regex("""regra de três\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)""").find(s)
        if (m != null) {
            val a = number(m.groupValues[1]); val b = number(m.groupValues[2]); val c = number(m.groupValues[3])
            if (a == 0.0) throw IllegalArgumentException("O primeiro valor não pode ser zero.")
            val answer = b * c / a
            return answer to listOf(
                "Montamos a proporção: $a corresponde a $b, e $c corresponde a x.",
                "Multiplicamos em cruz: x = ($b × $c) ÷ $a.",
                "x = ${fmtStatic(answer)}."
            )
        }

        val percentOnly = Regex("""(-?\d+(?:\.\d+)?)\s*%""").matchEntire(s)
        if (percentOnly != null) {
            val p = number(percentOnly.groupValues[1]); val answer = p / 100.0
            return answer to listOf(
                "Porcentagem significa uma quantidade em cada 100.",
                "$p% = $p ÷ 100.",
                "O valor decimal é ${fmtStatic(answer)}."
            )
        }

        s = s.replace(" mais ", "+").replace(" menos ", "-")
            .replace(" vezes ", "*").replace(" multiplicado por ", "*")
            .replace(" dividido por ", "/").replace(" sobre ", "/")
            .replace(" elevado a ", "^")
        val parser = ExpressionParser(s)
        val answer = parser.parse()
        return answer to listOf(
            "Interpretamos a expressão: $s.",
            "Resolvemos primeiro parênteses e potências, depois multiplicações e divisões, e por fim adições e subtrações.",
            "Resultado: ${fmtStatic(answer)}."
        )
    }

    private fun fmtStatic(v: Double): String {
        if (!v.isFinite()) return "indefinido"
        return if (v % 1.0 == 0.0) v.toLong().toString()
        else String.format(Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
    }
}

private class ExpressionParser(private val input: String) {
    private var pos = 0

    fun parse(): Double {
        val value = expression()
        skip()
        if (pos != input.length) throw IllegalArgumentException("Trecho não reconhecido: ${input.substring(pos)}")
        if (!value.isFinite()) throw IllegalArgumentException("Resultado inválido.")
        return value
    }

    private fun skip() { while (pos < input.length && input[pos].isWhitespace()) pos++ }

    private fun expression(): Double {
        var v = term()
        while (true) {
            skip()
            if (eat('+')) v += term()
            else if (eat('-')) v -= term()
            else return v
        }
    }

    private fun term(): Double {
        var v = power()
        while (true) {
            skip()
            if (eat('*')) v *= power()
            else if (eat('/')) {
                val d = power()
                if (d == 0.0) throw IllegalArgumentException("Não é possível dividir por zero.")
                v /= d
            } else if (eat('%')) v /= 100.0
            else return v
        }
    }

    private fun power(): Double {
        var v = unary()
        skip()
        if (eat('^')) v = v.pow(power())
        return v
    }

    private fun unary(): Double {
        skip()
        if (eat('+')) return unary()
        if (eat('-')) return -unary()
        if (eat('(')) {
            val v = expression()
            skip()
            if (!eat(')')) throw IllegalArgumentException("Faltou fechar um parêntese.")
            return v
        }
        if (input.startsWith("sqrt(", pos) || input.startsWith("raiz(", pos)) {
            pos = input.indexOf('(', pos) + 1
            val v = expression()
            skip()
            if (!eat(')')) throw IllegalArgumentException("Faltou fechar a raiz.")
            if (v < 0) throw IllegalArgumentException("Raiz de número negativo não é real.")
            return sqrt(v)
        }
        if (input.startsWith("pi", pos)) { pos += 2; return Math.PI }
        if (input.startsWith("e", pos)) { pos++; return Math.E }
        val start = pos
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("Esperava um número na posição ${pos + 1}.")
        return input.substring(start, pos).toDoubleOrNull()
            ?: throw IllegalArgumentException("Número inválido.")
    }

    private fun eat(c: Char): Boolean {
        if (pos < input.length && input[pos] == c) { pos++; return true }
        return false
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexuscalc.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexuscalc.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
